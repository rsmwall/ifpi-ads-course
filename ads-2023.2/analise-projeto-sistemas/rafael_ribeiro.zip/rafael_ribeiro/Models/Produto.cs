using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace rafael_ribeiro.Models
{
    public class Produto
    {
        [Display(Name = "Código")]
        public int Id {get; set;}
        [Display(Name = "Descrição")]
        public string Descricao {get; set;}
        [Display(Name = "Caminho da Imagem")]
        public string PathImage {get; set;}
        [Display(Name = "Preço (R$)")]
        public float Preco {get; set;}
        [Display(Name = "Quantidade")]
        public int Quantidade {get; set;}
        [Display(Name = "Categoria")]
        public int Categoria {get; set;}
    }
}