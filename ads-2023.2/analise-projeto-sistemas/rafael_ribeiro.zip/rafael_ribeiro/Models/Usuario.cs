using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace rafael_ribeiro.Models
{
    public class Usuario
    {   
        [Display(Name = "Código")]
        public int Id {get; set;}
        [Display(Name = "Login")]
        public string Nome {get; set;}
        [Display(Name = "E-mail")]
        public string Email {get; set;}
    }
}